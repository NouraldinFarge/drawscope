Up-to-date Powerball draw history from the official site.

Columns: date, num1, num2, num3, num4, num5, powerball, powerplay

Coverage: 1992-04-22 to 2026-07-27 (inclusive).

Total draws: 3813.

Automated updates occur shortly after scheduled drawings (Mon, Wed, Sat).

Please report any issues in the Discussion tab at https://www.kaggle.com/datasets/barefootjoey/powerball-draw-history/discussion?sort=hotness